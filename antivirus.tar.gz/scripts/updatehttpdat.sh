cd /home/isgopr/temp
if [ $# -eq 0 ];then
echo Please Specify Dat version You want to download
echo "sh updatehttpdat.sh <dat_version> "
exit
fi
echo Connecting to nai.com for the specified dat files
wget http://download.nai.com/products/datfiles/4.x/nai/dat-$1.tar

if [ $? -eq 0 ]; then
echo Datfiles Tar  downloaded successfully........
fi
echo extracting datfiles to /home/isgopr/datfiles

ls /home/isgopr/temp  > /home/isgopr/temp.txt

tar -xvf  `cat /home/isgopr/temp.txt` -C /home/isgopr/temp/
if [ $? -eq 0 ]; then
echo Datfiles extracted successfully........
fi

cd /home/isgopr/datfiles/
cp -f /home/isgopr/temp/clean.dat ./
if [ $? -eq 0 ]; then
echo clean.dat copied successfully
fi

cp -f /home/isgopr/temp/scan.dat ./
if [ $? -eq 0 ]; then
echo names.dat copied successfully
fi
cp -f /home/isgopr/temp/internet.dat ./
if [ $? -eq 0 ]; then
echo internet.dat copied successfully
fi
cp -f /home/isgopr/temp/names.dat ./
if [ $? -eq 0 ]; then
echo scan.dat copied successfully
fi

rm -rf /home/isgopr/temp/*
rm -rf /home/igsopr/temp.txt
if [ $? -eq 0 ]; then
echo Temprary files removed.....
fi

echo Latest datfiles successfully extracted to /home/isgopr/datfiles


