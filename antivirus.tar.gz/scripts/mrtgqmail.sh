/usr/bin/mrtg /home/qmailmrtg7-4.0/qmail.mrtg.cfg
