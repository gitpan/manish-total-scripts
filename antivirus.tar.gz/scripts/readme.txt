       Release Notes for McAfee DAT Files
            Copyright (c) 1992-2004
      Networks Associates Technology, Inc.
              All Rights Reserved

===============================================


Thank you for using our products. This file
contains important information about the
current virus definition (DAT) files. We
recommend that you read the entire document.

You must have a current PrimeSupport agreement 
in order to be entitled to download product 
updates and upgrades, including engine and DAT 
updates. By downloading any of these files,  
you acknowledge that you currently have a 
valid PrimeSupport agreement with Network 
Associates.

The DAT files supplied with this README file
are compatible with our anti-virus products
that use the version 4.3.20 (or later)
virus-scanning engine. We recommend that you
upgrade to the latest version of the
virus-scanning engine for optimal virus
detection and cleaning.


_______________________________________________
WHAT�S IN THIS FILE?

-  What are DAT files?
-  How we provide the DAT files
-  Which file to use
   -  When to use the XDAT file
   -  When to use the compressed DAT package
      (DAT-)
-  Installation
   -  Using the DAT Package Installer (XDAT
      file)
   -  Using the DAT ZIP or DAT TAR file to
      update VirusScan Command Line and
      VirusScan for UNIX
   -  Using the DAT ZIP or DAT TAR file to
      update other products
   -  VirusScan 4.5 for Microsoft Windows
   -  VirusScan 4.0.3 for Microsoft Windows 95
      and Windows 98
   -  VirusScan 4.0.3 for Microsoft Windows NT and
      Netshield 4.0.3 for Microsoft Windows NT
   -  Netshield for Novell NetWare
   -  GroupShield for Lotus Notes
   -  List of Virus Definition Files
   -  Testing your installation
-  New Viruses Detected and Removed
-  Understanding Virus Names
   -  Prefix
   -  Prefix for Trojan-Horse classes
   -  Infix
   -  Suffix
   -  Generic Detections
   -  Heuristic Detections
   -  Application Detections
-  Documentation
-  Contacting McAfee Security & Network
   Associates
-  Copyright and Trademark Attributions
   -  Trademarks
   -  License Agreement


_______________________________________________
WHAT ARE DAT FILES?

Virus definition, or DAT, files contain
up-to-date virus signatures and other
information that our anti-virus products use to
protect your computer against thousands of
computer viruses and other potentially harmful
software in circulation. Hundreds of new
threats appear each month. Every week, we
release new DAT files. We also release new DAT
files when any threat is assessed by AVERT to
have a medium or higher risk.

To ensure that your anti-virus software can
protect your system or network against the
latest threats, you must download and install
the latest DAT files. For their location, see
"CONTACTING MCAFEE SECURITY & NETWORK
ASSOCIATES".


_______________________________________________
HOW WE PROVIDE THE DAT FILES

We store new DAT files on our web site in
several compressed formats to reduce
transmission time:

-  Compressed DAT Package. This file contains
   the DAT files, compressed in a ZIP or tar
   file. You can extract and install them
   yourself to update most of our anti-virus
   software. The file has a name of the format
   DAT-4316.ZIP or DAT-4316.tar, where 4316 is
   the four-digit DAT version number such as
   4321.

-  DAT Package Installer, or "XDAT file". This
   file includes the DAT files plus an
   executable that installs them. The file has
   a name of the format 4316XDAT.EXE, where
   4316 is the four-digit DAT version number
   such as 4321.

-  SuperDAT Package Installer, or "SDAT file".
   This file includes the DAT files plus an
   executable that installs them. It may also
   include a new virus-scanning engine and
   other program components. The file has a
   name of the format SDAT4316.EXE, where 4316
   is the four-digit DAT version number such as
   4321.

   NOTE:
   This README file does NOT describe how to
   use the SuperDAT Package Installer. For more
   information, see the README file posted with
   that package.


_______________________________________________
WHICH FILE TO USE

WHEN TO USE THE XDAT FILE

The XDAT file makes DAT file updating quick and
simple. Unlike the SuperDAT Package Installer,
this installer does not update the
virus-scanning engine for your anti-virus
software. Hence, you can use this installer
when your engine is up-to-date and you do not
want to download the larger SuperDAT Package
Installer file.

The XDAT file is a standard application that
you can double-click to start from within
Microsoft Windows.

It installs new DAT files to keep your
anti-virus software up to date. It shuts down
any active anti-virus scans, services, or other
memory-resident software components that might
interfere with your updates. It then copies the
new files to their proper locations and enables
your anti-virus software to use them
immediately.

This installer supports the same platforms and
products as the SuperDAT Package Installer.

This installer is compatible with most of our
version 4.x anti-virus products, including most
version 4.5 product versions.

This installer does NOT support the following:

-  Any Dr Solomon Anti-Virus Toolkit product.

-  VirusScan for UNIX.

-  GroupShield for Lotus Notes.

-  NetShield for Novell NetWare.


WHEN TO USE THE COMPRESSED DAT PACKAGE (DAT-)

A compressed DAT package allows you to update
the DAT files for any supported McAfee version
4.x anti-virus product.

The difference between this package and the
installers (SDAT and XDAT files) is that you
must stop any scans or virus-scanning services
and unload any Terminate-and-Stay-Resident
(TSR) programs from your computer's memory
yourself. You must then copy the new files to
the program directory of your anti-virus
software, then restart the services or
background-scanning software that your
application uses.

Alternatively, if your anti-virus software has
an AutoUpdate feature, you can configure that
to download and install the package for you.
Version 4.5-series anti-virus software can also
use incremental DAT file updating. For more
information, see your product documentation.

The following products need the compressed DAT
package to update your anti-virus protection:

-  VirusScan for UNIX

-  GroupShield for Lotus Notes

-  WebShieldX Proxy

-  Netshield for Novell NetWare

To learn how to update these products, see
"Installation".


_______________________________________________
INSTALLATION


USING THE DAT PACKAGE INSTALLER (XDAT FILE)

1. Create a temporary directory on your hard
   disk.

2. Download the XDAT file to the temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates".

3. Double-click the XDAT file to start the
   update.

4. Follow the instructions in the wizard
   panels.

   The installer then does the following:

   -  Unloads McAfee memory-resident software
      or stops services that use your current
      DAT files.

   -  Copies new DAT files to the appropriate
      program directories.

   -  Restarts the software components needed
      to continue scans with your new DAT
      files.

5. When the installer has finished updating
   your DAT files, you may delete the file you
   downloaded, unless you want to keep a copy
   available for further updates.


USING THE DAT ZIP OR DAT TAR FILE TO UPDATE
VIRUSSCAN COMMAND LINE AND VIRUSSCAN FOR UNIX

1. Create a temporary directory on your hard
   disk.

2. Download the compressed DAT file to the
   temporary directory from our web site. See
   "Contacting McAfee Security & Network
   Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP or DAT-4316.tar, where 4316 is
   the DAT version number, such as 4321.

3. If your anti-virus software has a version of
   VShield running, enter VSHIELD /REMOVE at
   the command-line prompt.

4. Back up or rename the existing DAT files,
   which are in the program directory for your
   anti-virus software. See "List of Virus
   Definition Files" later in this file for a
   complete DAT file list.

5. Using WinZip, PKUnzip, or a similar utility,
   open the ZIP file and extract the new DAT
   files. You can save the extracted files
   directly to the program directory for your
   anti-virus software.

   To extract DAT files stored in a tar file,
   use a compression utility that can read and
   extract tar files, or follow these steps
   from a UNIX command prompt:

   1. Change to the directory into which you
      want to extract the new DAT files. This
      is the program directory for your
      anti-virus software, or a temporary
      directory from which you intend to copy
      the new files.

   2. Enter this command at the command
      prompt:

      tar xf <directory path>/dat-4316.tar

      Here, <directory path> is the path to the
      tar file you downloaded. The tar utility
      will extract the DAT files into your
      current working directory.

      NOTE:
      The syntax for the tar command might vary
      in different UNIX versions. Consult your
      manual pages or other product
      documentation for more details.

6. Copy the new DAT files to the program
   directory for the software you want to
   update. Allow the new files to replace the
   existing files.

7. If your anti-virus software includes a
   VShield component, enter VSHIELD, followed
   by the scanning options you want, at the
   command-line prompt.

   NOTE:
   When you have finished using the compressed
   DAT file, you may delete it from your hard
   disk, unless you want to keep a copy for
   further updates.


USING THE DAT ZIP OR DAT TAR FILE TO UPDATE
OTHER PRODUCTS

We recommend that you use either the SuperDAT
Installer (SDAT file), or the DAT Installer
(XDAT file) to install new DAT files. These
installers provide an easy and foolproof method
for correctly updating DAT files.

However, if you want to install new DAT files
directly from the ZIP or tar file, locate the
heading for your anti-virus product in the list
below, then follow the steps in the
corresponding section.

-  VirusScan 4.5 for Microsoft Windows�95,
   Windows 98, Windows NT Workstation 4.0, and
   Windows 2000 Professional

-  VirusScan 4.0.3 for Microsoft Windows 95 and
   Windows 98

-  VirusScan 4.0.3 for Microsoft Windows NT and
   Netshield 4.0.3 for Microsoft Windows NT

-  NetShield for Novell Netware

-  GroupShield for Lotus Notes


VIRUSSCAN 4.5 FOR MICROSOFT WINDOWS

1. Create a temporary directory on your hard
   disk.

2. Download the DAT ZIP file to the temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

3. Click Start in the Windows task bar, point
   to Settings, then choose Control Panel.

4. Locate the VirusScan control panel, then
   double-click it to open it.

5. Click Stop on the Service page. Leave the
   VirusScan control panel open. You need to
   return to it in a later step.

6. Back up or rename the existing DAT files
   stored in the Network Associates Common
   Files directory. If you installed VirusScan
   software to its default location, the
   directory is:

      C:\Program Files\Common Files\Network Associates\VirusScan Engine\4.x.xx

   See "List of Virus Definition Files" later
   in this file for a complete DAT file list.

7. Using WinZip, PKUnzip, or a similar utility,
   open the ZIP file and extract the new DAT
   files.

   Save the extracted files directly to the
   Network Associates Common Files directory.
   Allow the new files to overwrite the
   existing DAT files.

8. Return to the VirusScan control panel, then
   click Start in the Service page.

   The VShield scanner and the VirusScan
   Console will start again. Your VirusScan
   software is now up to date.


VIRUSSCAN 4.0.3 FOR MICROSOFT WINDOWS 95 AND
WINDOWS 98

1. Create a temporary directory on your hard
   disk.

2. Download the compressed DAT file to the
   temporary directory from our web site. For
   the location, see "Contacting McAfee
   Security & Network Associates" later in this
   file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

3. Right-click the VShield icon that appears in
   your Windows system tray at the bottom,
   right-hand corner of your screen to display
   the VShield shortcut menu.

4. Point to Enable, then choose System Scan to
   remove the checkmark beside the name. This
   disables the VShield System Scan module.

5. Repeat Steps 1 and 2 to disable all of the
   remaining VShield modules: E-Mail Scan,
   Download Scan, and Internet Filter.

6. Restart your computer to remove all VShield
   modules from memory.

7. Back up or rename the existing DAT files
   stored in the VirusScan program directory.
   See "List of Virus Definition Files" later
   in this file for a complete DAT file list.

8. Using WinZip, PKUnzip, or a similar utility,
   open the DAT ZIP file and extract the new
   DAT files. You can save the extracted files
   directly to the VirusScan program directory.
   Allow the new files to overwrite the
   existing DAT files.

9. Restart your computer.

10. Right-click the VShield icon that appears
   in your Windows system tray at the bottom,
   right-hand corner of your screen to display
   the VShield shortcut menu.

11. Point to Enable, then choose one of the
   listed VShield modules to add a checkmark
   beside the name. This enables that VShield
   module again.

   Begin with the System Scan module, then
   repeat Steps 9 and 10 to enable these
   remaining VShield modules: E-Mail Scan,
   Download Scan, and Internet Filter.


VIRUSSCAN 4.0.3 FOR MICROSOFT WINDOWS NT
AND NETSHIELD 4.0.3 FOR MICROSOFT WINDOWS NT

If you have Administrator rights for the server
or workstation you want to update, you can
initiate update requests at any time to
VirusScan for Windows NT and NetShield for
Windows NT:

1. Create a temporary directory on your hard
   disk.

2. Download the DAT ZIP file to the temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

3. Using the AntiVirus Console, connect to the
   workstation or server you want to update.

4. Double-click the AutoUpdate task to open it,
   then click Update Now.

   The program retrieves new files from the
   location specified in the task settings, and
   installs the new files correctly.

To install new DAT files directly from a DAT
ZIP file WITHOUT using AutoUpdate:

   NOTE:
   We do not recommend this method of updating
   your DAT files.

1. Download the DAT ZIP file to a temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

2. Back up or rename the existing DAT files
   stored in the program directory. See "List
   of Virus Definition Files" later in this
   file for a complete DAT file list.

3. Using WinZip, PKUnzip, or a similar utility,
   open the ZIP file, and extract the new DAT
   files.

4. Log on to the server or workstation you want
   to update. You must have Administrator
   rights for the target computer.

5. Click Start, point to Settings, then choose
   Control Panel. In the window, locate and
   double-click the Services control panel to
   open it.

   If the computer is running Windows NT 3.51,
   start Program Manager, then locate the
   Control Panels program group. Double-click
   the program group to open it, then locate
   and double-click the Services control
   panel.

6. Select the Network Associates McShield
   Service, then click Stop.

7. Copy the DAT files you extracted from the
   ZIP file to the program directory.

8. Return to the Services control panel,
   select the McShield Service, then click
   Start.

9. Close the Services control panel.

The new DAT files are used in anti-virus scans
immediately.


NETSHIELD FOR NOVELL NETWARE

To install DAT file updates directly from a ZIP
file WITHOUT using the AutoUpdate utility:

   NOTE:
   We do not recommend this method of updating
   your DAT files.

1. Create a temporary directory on your hard
   disk.

2. Download the DAT ZIP file to the temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

3. Using WinZip, PKUnzip, or a similar utility,
   open the ZIP file, and extract the new DAT
   files.

4. Log on to the server you want to update. You
   must have administrator rights for the
   target server.

5. At the NetWare Console prompt, enter:

      unload netshld

6. Back up or rename the existing DAT files
   stored in your NetShield program directory.
   If you installed NetShield to the default
   program directory, the DAT files are at this
   location:

      SYS:MCAFEE\NETSHLD

   See "List of Virus Definition Files" later
   in this file for a complete DAT file list.

7. Copy the files you extracted from the
   temporary directory you created in Step 1 to
   the NetShield program directory on your
   server.

8. Enter this line at the NetWare Console
   prompt to restart the NetShield NetWare
   server software:

      netshld

   NetShield uses the new DAT files in
   anti-virus scans immediately.


GROUPSHIELD FOR LOTUS NOTES

GroupShield for Lotus Notes allows you to
download and install new DAT files with its
automatic update feature. We recommend this
method, but you can also update your DAT files
directly.

1. Create a temporary directory on your hard
   disk.

2. Download the DAT ZIP file to the temporary
   directory from our web site. For the
   location, see "Contacting McAfee Security &
   Network Associates" later in this file.

   The name of the file is typically
   DAT-4316.ZIP, where 4316 is the DAT version
   number, such as 4321.

3. Back up or rename the existing DAT files
   stored in the GSUPDATE.NSF database. See
   "List of Virus Definition Files" later in
   this file for a complete DAT file list.

4. Using WinZip, PKUnzip, or a similar utility,
   open the ZIP file and extract the new DAT
   files.

5. Start Lotus Notes, then right-click
   Workspace. From the menu that appears,
   choose Open Database.

6. Locate the database GSUPDATE.NSF, then add
   to that database those files that you
   extracted into the temporary directory you
   created in Step 1.

   GroupShield for Lotus Notes will use the new
   DAT files as soon as they replicate across
   the network. If you have partitioned Notes
   servers, you must shut down and restart each
   of the partitioned servers for the update to
   take effect.


LIST OF VIRUS DEFINITION FILES

The virus definition files (or DAT files)
included in the packages are:

   SCAN.DAT             Data file for virus
                        scanning

   NAMES.DAT            Data file for virus
                        names

   CLEAN.DAT            Data file for virus
                        cleaning

   INTERNET.DAT         Data file for detecting
                        hostile Java/ActiveX
                        objects.


TESTING YOUR INSTALLATION

You can test the operation of the software by
running the EICAR Standard AntiVirus Test File
on any computer where you have installed the
software. The EICAR Standard AntiVirus Test
File is a combined effort by anti-virus vendors
throughout the world to implement one standard
by which customers can verify their anti-virus
installations.

To test your installation:

1. Copy the following line into its own file,
   then save the file with the name EICAR.COM.

      X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*

   The file size will be 68 or 70 bytes.

2. Start your anti-virus software and allow it
   to scan the directory that contains
   EICAR.COM.

   When your software scans this file, it will
   report finding the EICAR test file.

3. Delete the file when you have finished
   testing your installation to avoid alarming
   unsuspecting users.

   IMPORTANT:
   Please note that this file is NOT A VIRUS.


_______________________________________________
NEW VIRUSES DETECTED AND REMOVED

Hundreds of new viruses and variants appear
each month. Those which are detected and
cleaned by AVERT's generic methods are added to
the total virus count listed but they are not
listed separately here.

For more information on new viruses detected
and removed by a specific DAT please refer
to the DAT Readme page at McAfee Security HQ

http://vil.nai.com/vil/DATReadme.asp
McAfee software removes a virus either by
deleting the infecting virus code from files or
by deleting the file from your computer.

_______________________________________________
UNDERSTANDING VIRUS NAMES

Our anti-virus software typically follows
industry-wide naming conventions to identify
the viruses that it detects and cleans.
Occasionally, some virus names deviate from
strict industry standards.

The first virus with a given set of
characteristics that mark it as a distinctly
new entity receives a "family" name. Virus
researchers draw the family name from some
identifying quirk or notation in the virus,
such as a text string, or a payload effect.

A family name can also include a numeric string
that designates the byte size of the virus.
Researchers use this name as convenient
shorthand to distinguish closely allied virus
variants.

Names for variants within a virus family
consist of the family name and a suffix -
BadVirus.a, for example. The suffix continues
in alphabetical order until it reaches z. Then
it begins again with aa and continues to az.
Still later variants receive the suffix ba
through bz, and so forth, until the suffix
reaches zz. If yet another variant appears
after that, it will have the suffix aaa.

As new virus strains appeared, industry naming
conventions evolved to include more
information. Some names, for instance, include
parts that identify the platform on which the
virus can run.

Among anti-virus vendors, virus names can
include a prefix, an infix and a suffix.


PREFIX

The prefix designates the type of file that the
virus infects or the platform on which
potentially harmful software can run. Viruses
that infect DOS executables do not receive a
prefix. Our naming convention includes the
following prefixes:

   A97M/    Macro virus that infects Microsoft
            Access 97 files.

   APM/     Macro virus or Trojan-horse program
            that infects Ami Pro document and
            template files.

   Bat/     Batch-file virus or Trojan-horse
            program. These viruses usually run
            as batch or script files that
            affect a particular program that
            interprets the script or batch
            commands they include. They are
            very portable and can affect nearly
            any platform that can run batch or
            script files. The files themselves
            often have a BAT extension.

   CSC/     Corel Script virus or Trojan-horse
            program that infects Corel Draw
            document files, template files, and
            scripts.

   IRC/     Internet Relay Chat script virus.
            This virus type can use early
            versions of the mIRC client
            software to distribute a virus or
            payload.

   JS/      Script virus or Trojan-horse
            program written in JavaScript
            language.

   JV/      Potentially harmful Java
            application or applet.

   Linux/   Virus or Trojan-horse program
            compiled for Linux OS in ELF file
            format.

   LWP/     Potentially harmful software for
            Lotus WordPro.

   MacHC/   Virus or Trojan-horse program for
            Apple Macintosh HyperCard scripting
            language.

   MacOS/   Virus or Trojan-horse program for
            Apple Macintosh OS Versions 6-9.

   MSIL/    Application written using Microsoft
            Intermediate Language framework,
            also known as .NET.

   P98M/    Macro virus or Trojan-horse program
            that infects Microsoft Project
            documents and templates.

   PalmOS/  Virus or Trojan-horse program for a
            Palm Pilot.

   PDF/     File-infector of Adobe PDF files.

   Perl/    Script virus or Trojan-horse
            program written in Perl language.

   PHP/     Script virus or Trojan-horse
            program written in PHP language.

   PP97M/   Macro virus. Infects Microsoft
            PowerPoint 97 files.

   SunOS/   Potentially harmful software for
            Sun Solaris.

   SWF/     Potentially harmful software for
            Shockwave.

   Unix/    Program or a shell script for a
            version of UNIX.

   V5M/     Macro or script virus, or
            Trojan-horse program that infects
            Visio VBA (Visual Basic for
            Applications) macros or scripts.

   VBS/     Script virus or Trojan-horse
            program written in Visual Basic
            Script language.

   W16/     File-infector virus that runs in
            16-bit Microsoft Windows
            environments (Windows 3.1x).

   W2K/     Potentially harmful software for
            32-bit Microsoft Windows
            environments, specifically Windows
            NT, 2000 or XP.

   W32/     File-infector or boot-sector virus
            that runs in 32-bit Microsoft
            Windows environments (Windows 95,
            Windows 98 or Windows NT).

   W95/     File-infector virus that runs in
            Microsoft Windows 95, Windows 98
            and Windows ME environments.

   W97M/    Macro virus that infects Microsoft
            Word�97 files.

   WHLP/    Potentially harmful software for
            32-bit Microsoft Windows
            environments that targets Windows
            HLP files.

   WM/      Macro virus that infects Microsoft
            Word 95 files.

   X97M/    Macro virus that infects Microsoft
            Excel 97 files.

   XF/      Macro virus that infects Microsoft
            Excel 95 or 97 via Excel formulas.

   XM/      Macro virus that infects Microsoft
            Excel 95 files.


PREFIX FOR TROJAN-HORSE CLASSES

A name such as "BackDoor-" denotes potentially
harmful software that belongs to a class of
similar Trojan-horse programs. The class name
is followed by extra characters to denote a
family (such as BackDoor-JZ) or a name (such as
BackDoor-Sub7).

   AdClicker-
            Repeatedly accesses web sites that
            are funded by advertising.

   Adware-  Installs advertising software but
            does not ask permission.

   BackDoor-
            Provides remote access or control
            through the Internet or network.

   Dialer-  Dials a phone number without asking
            for permission.

   DDoS-    Operates as a Distributed Denial of
            Service component.

   Del-     Deletes files.

   Downloader-
            Downloads software from the
            Internet, usually to deliver
            backdoors, password stealers, and
            sometimes viruses.

   Exploit- Uses a vulnerability or a software
            defect.

   FDoS-    Denotes a Flooding Denial of
            Service component.

   KeyLog-  Logs keystrokes for immediate or
            future transmission to the
            attacker.

   Kit-     Denotes a program designed for
            creating a virus or Trojan-horse
            program.

   MultiDropper-
            Drops several Trojan-horse program
            or viruses (often several different
            �backdoors�).

   Nuke-    Uses defects in software on a
            remote computer to bring it down.

   ProcKill-
            Terminates the processes of
            anti-virus and security products.
            May also delete files associated
            with such applications.

   PWS-     Steals a password.

   Reboot-  Reboots the computer.

   Reg-     Modifies the Registry in an
            undesirable fashion without asking
            questions. For example, reduces the
            security settings or creates
            abnormal associations or sets.

   Spam-    Acts as a spamming tool.

   Spyware- Monitors browsing habits or other
            behavior and sends the information
            out, often for unsolicited
            advertising.

   Uploader-Sends files or other data from the
            computer.

   Vtool-   Denotes a program used by virus
            writers or hackers for developing
            software.

   Zap-     Wipes all or part of a hard disk.


INFIX

These designations usually appear in the middle
of a virus name. AVERT assigns these
designations, which differ from industry
conventions.

   .cmp.    Companion file that the virus adds
            to an existing executable file. Our
            anti-virus software deletes the
            companion file to prevent later
            infections.

   .mp.     Legacy multi-partite virus for
            DOS.

   .ow.     Overwriting virus. This identifies
            a virus that overwrites data in a
            file, thereby irreparably
            corrupting it. This file must be
            deleted.


SUFFIX

These designations usually appear as the last
part of a virus name. A virus name can have
more than one suffix. One might designate a
variant, for example, while others give
additional information.

   @M       Slow mailer. This virus uses an
            e-mail system to spread. It usually
            replies to an incoming message
            once, or attaches itself to an
            outgoing message, or sends to just
            one e-mail address.

   @MM      Mass mailing distribution. This
            virus might use standard techniques
            to propagate itself, but also uses
            an e-mail system to spread.

   .a - .zzz Virus variants.


In accordance with the CARO (Computer
Anti-virus Research Organization) naming
convention, the vendor-specific suffices can be
preceded by a "!" character. Our software uses
the following suffices:


   apd      Appended virus. A virus that
            appends its code to the file it
            infects, but fails to provide for
            correct replication.

   bat      Software component in BAT
            language.

   cav      Cavity virus. This designates a
            virus that copies itself into
            "cavities" (for example, areas of
            all zeroes) in a program file.

   cfg      Configuration component of an
            Internet Trojan-horse program
            (frequently of a �BackDoor-�).

   cli      Client-side component of an
            Internet Trojan-horse program
            (frequently of a �BackDoor-�).

   dam      Damaged file. A file that is
            damaged or corrupted by an
            infection.

   demo     Program that demonstrates
            potentially harmful action, such as
            an example of how an exploit
            works.

   dr       Dropper file. This file introduces
            the virus into the host program.

   gen      Generic detection. Native routines
            in our software detect this virus
            without using specific code
            strings.

   ini      An mIRC or pIRCH script when it is
            a component of another virus.

   intd     "Intended" virus. This virus has
            most of the usual virus
            characteristics but cannot
            replicate correctly.

   irc      IRC component of potentially
            harmful software.

   js       Potentially harmful software
            component in JavaScript.

   kit      Virus or Trojan-horse program
            created from a �virus construction
            kit�.

   p2p      Potentially harmful software that
            uses peer-to-peer communication to
            function. For example, Gnutella and
            Kazaa.

   sfx      Self-extracting installation
            utility for Trojan-horse programs.

   src      Viral source code. This ordinarily
            cannot replicate or infect files,
            but some virus droppers add this to
            files as part of the infection
            cycle. Our products routinely flag
            files with additional code of this
            sort for deletion.

   sub      Substitution virus. It substitutes
            the host file with itself, so that
            all infected hosts are of the same
            size and are a pure virus. (That
            is, a subclass of overwriting
            viruses.)

   svr      Server-side component of an
            Internet Trojan-horse program,
            often of a �backdoor�.

   vbs      Potentially harmful software
            component written in Visual Basic
            Script language.

   worm     A non-parasitic virus that copies
            itself, or a virus that propagates
            through a network by copying to
            remote computers or by sending
            itself out via any means of file
            transmission such as remote shares,
            peer-to-peer, instant messaging,
            IRC file transfers, FTP, and SMTP.


GENERIC DETECTIONS

Our software detects a huge amount of
potentially harmful software proactively and
generically. In most cases, such objects are
successfully cleaned even without AVERT ever
receiving a sample. Such detection is denoted
by "Generic" in the name or a "gen" suffix.

To submit a sample to AVERT, visit the AVERT
home page. See "CONTACTING MCAFEE SECURITY &
NETWORK ASSOCIATES".


HEURISTIC DETECTIONS

Our software detects a huge amount of new
potentially harmful software heuristically.
Such detection is flagged using the "New"
prefix to the name (for example "New Worm" and
"New Win32").

To submit any sample that was detected
heuristically, visit the AVERT home page. See
"CONTACTING MCAFEE SECURITY & NETWORK
ASSOCIATES".


APPLICATION DETECTIONS

Our software detects potentially unwanted
applications; they cannot be classified as
viruses or Trojan-horse programs. They include
some Adware, Spyware, Dialers, remote-access
software that can hide itself, and other
similar applications that many users do not
want on their computers. Unwanted applications
also include �jokes� but these can be excluded
from detection using scanning options.

For more information, visit the AVERT home
page. See "CONTACTING MCAFEE SECURITY & NETWORK
ASSOCIATES".


_______________________________________________
DOCUMENTATION

This product includes the following documents:

-  This README file.

-  A CONTACT file.
   Contact information for McAfee Security and
   Network Associates services and resources:
   technical support, customer service, AVERT,
   beta program, and training. It also includes
   a list of phone numbers, street addresses,
   web addresses, e-mail addresses, and fax
   numbers for Network Associates offices in
   the United States and around the world.


__________________________________________________________
CONTACTING MCAFEE SECURITY & NETWORK ASSOCIATES

Technical Support
    Home Page
       http://www.networkassociates.com/us/support/

    KnowledgeBase Search
       https://knowledgemap.nai.com/phpclient/homepage.aspx

    PrimeSupport Service Portal
       http://mysupport.nai.com

Login credentials required.


McAfee Security Beta Program
    Beta Web Site
       http://www.networkassociates.com/us/downloads/beta/

    E-mail
       avbeta@nai.com


Security Headquarters -- AVERT (Anti-Virus Emergency
Response Team)
    Home Page
       http://www.networkassociates.com/us/security/home.asp

    Virus Information Library
       http://vil.nai.com

    Submit a Virus Sample - AVERT WebImmune
       https://www.webimmune.net/default.asp

    AVERT DAT Notification Service
       http://vil.nai.com/vil/join-DAT-list.asp


Download Site
    Home Page
       http://www.networkassociates.com/us/downloads/

    DAT File and Engine Updates
       http://www.networkassociates.com/us/downloads/updates/

       ftp://ftp.nai.com/pub/antivirus/datfiles/4.x

    Product Upgrades
       https://secure.nai.com/us/forms/downloads/upgrades/login.asp

Valid grant number required.
Contact Network Associates Customer Service


Training
    McAfee Security University
       http://www.networkassociates.com/us/services/education/mcafee/university.htm


Network Associates Customer Service
    US, Canada, and Latin America toll-free:
   Phone:     +1-888-VIRUS NO or +1-888-847-8766
              Monday - Friday, 8 a.m. - 8 p.m.,
              Central Time

   E-mail:    services_corporate_division@nai.com
   Web:       http://www.nai.com/us/index.asp
              http://www.networkassociates.com/us/index.asp


For additional information on contacting Network
Associates and McAfee Security - including toll-free
numbers for other geographic areas -- see the
CONTACT file that accompanied your original product
release.


__________________________________________________________
COPYRIGHT AND TRADEMARK ATTRIBUTIONS 

Copyright (C) 2004 Networks Associates
Technology, Inc. All Rights Reserved. No part of
this publication may be reproduced, transmitted,
transcribed, stored in a retrieval system, or
translated into any language in any form or by any
means without the written permission of Networks
Associates Technology, Inc., or its suppliers or
affiliate companies. To obtain this permission,
write to the attention of the Network Associates
legal department at:
5000 Headquarters Drive, Plano, Texas 75024, or call
+1-972- 963-8000.


TRADEMARKS

Active Firewall, Active Security, Active Security
(in Katakana), ActiveHelp, ActiveShield, AntiVirus
Anyware and design, Appera, AVERT, Bomb Shelter,
Certified Network Expert, Clean-Up, CleanUp Wizard,
ClickNet, CNX, CNX Certification Certified Network
Expert and design, Covert, Design (stylized N), Disk
Minder, Distributed Sniffer System, Distributed
Sniffer System (in Katakana), Dr Solomon�s, Dr
Solomon�s label, E and Design, Entercept, Enterprise
SecureCast, Enterprise SecureCast (in Katakana),
ePolicy Orchestrator, Event Orchestrator (in
Katakana), EZ SetUp, First Aid, ForceField, GMT,
GroupShield, GroupShield (in Katakana), Guard Dog,
HelpDesk, HelpDesk IQ, HomeGuard, Hunter, Impermia,
InfiniStream, Intrusion Prevention Through
Innovation, IntruShield, IntruVert Networks,
LANGuru, LANGuru (in Katakana), M and design, Magic
Solutions, Magic Solutions (in Katakana), Magic
University, MagicSpy, MagicTree, McAfee, McAfee (in
Katakana), McAfee and design, McAfee.com, MultiMedia
Cloaking, NA Network Associates, Net Tools, Net
Tools (in Katakana), NetAsyst, NetCrypto,
NetOctopus, NetScan, NetShield, NetStalker, Network
Associates, Network Performance Orchestrator,
NetXray, NotesGuard, nPO, Nuts & Bolts, Oil Change,
PC Medic, PCNotary, PortalShield, Powered by
SpamAssassin, PrimeSupport, Recoverkey, Recoverkey -
International, Registry Wizard, Remote Desktop,
ReportMagic, RingFence, Router PM, Safe & Sound,
SalesMagic, SecureCast, SecureSelect,
SecurityShield, Service Level Manager, ServiceMagic,
SmartDesk, Sniffer, Sniffer (in Hangul), SpamKiller,
SpamAssassin, Stalker, SupportMagic, ThreatScan,
TIS, TMEG, Total Network Security, Total Network
Visibility, Total Network Visibility (in Katakana),
Total Service Desk, Total Virus Defense, Trusted
Mail, UnInstaller, VIDS, Virex, Virus Forum,
ViruScan, VirusScan, WebScan, WebShield, WebShield
(in Katakana), WebSniffer, WebStalker, WebWall,
What's The State Of Your IDS?, Who�s Watching Your
Network, WinGauge, Your E-Business Defender, ZAC
2000, Zip Manager are registered trademarks or
trademarks of Network Associates, Inc. and/or its
affiliates in the US and/or other countries.
Sniffer(R) brand products are made only by Network
Associates, Inc. All other registered and
unregistered trademarks herein are the sole property
of their respective owners.


LICENSE INFORMATION

License Agreement

NOTICE TO ALL USERS: CAREFULLY READ THE APPROPRIATE
LEGAL AGREEMENT CORRESPONDING TO THE LICENSE YOU
PURCHASED, WHICH SETS FORTH THE GENERAL TERMS AND
CONDITIONS FOR THE USE OF THE LICENSED SOFTWARE. IF
YOU DO NOT KNOW WHICH TYPE OF LICENSE YOU HAVE
ACQUIRED, PLEASE CONSULT THE SALES AND OTHER RELATED
LICENSE GRANT OR PURCHASE ORDER DOCUMENTS THAT
ACCOMPANIES YOUR SOFTWARE PACKAGING OR THAT YOU HAVE
RECEIVED SEPARATELY AS PART OF THE PURCHASE (AS A
BOOKLET, A FILE ON THE PRODUCT CD, OR A FILE
AVAILABLE ON THE WEB SITE FROM WHICH YOU DOWNLOADED
THE SOFTWARE PACKAGE). IF YOU DO NOT AGREE TO ALL OF
THE TERMS SET FORTH IN THE AGREEMENT, DO NOT INSTALL
THE SOFTWARE. IF APPLICABLE, YOU MAY RETURN THE
PRODUCT TO NETWORK ASSOCIATES, INC. OR THE PLACE OF
PURCHASE FOR A FULL REFUND.


Attributions

This product includes or may include:

-   Software developed by the OpenSSL Project for
    use in the OpenSSL Toolkit
    (http://www.openssl.org/).

-   Cryptographic software written by Eric Young and
    software written by Tim J. Hudson.

-   Some software programs that are licensed (or
    sublicensed) to the user under the GNU General
    Public License (GPL) or other similar Free
    Software licenses which, among other rights,
    permit the user to copy, modify and redistribute
    certain programs, or portions thereof, and have
    access to the source code.  The GPL requires
    that for any software covered under the GPL
    which is distributed to someone in an executable
    binary format, that the source code also be made
    available to those users.  For any such software
    covered under the GPL, the source code is made
    available on this CD.  If any Free Software
    licenses require that Network Associates provide
    rights to use, copy or modify a software program
    that are broader than the rights granted in this
    agreement, then such rights shall take
    precedence over the rights and restrictions
    herein.

-   Software originally written by Henry Spencer,
    Copyright 1992, 1993, 1994, 1997 Henry Spencer.

-   Software originally written by Robert Nordier,
    Copyright (C) 1996-7 Robert Nordier. All rights
    reserved.

-   Software written by Douglas W. Sauder.

-   Software developed by the Apache Software
    Foundation (http://www.apache.org/).

-   International Components for Unicode ("ICU")
    Copyright (C) 1995-2002 International Business
    Machines Corporation and others. All rights
    reserved.

-   Software developed by CrystalClear Software,
    Inc., Copyright (C) 2000 CrystalClear Software,
    Inc.

-   FEAD(R) Optimizer(R) technology, Copyright
    Netopsystems AG, Berlin, Germany.

-   Outside In(R) Viewer Technology (C) 1992-2001
    Stellent Chicago, Inc. and/or Outside In(R) HTML
    Export, (C) 2001 Stellent Chicago, Inc.

-   Software copyrighted by Thai Open Source
    Software Center Ltd. and Clark Cooper, (C) 1998,
    1999, 2000.

-   Software copyrighted by Expat maintainers.

-   Software copyrighted by The Regents of the
    University of California, (C) 1989.

-   Software copyrighted by Gunnar Ritter.

-   Software copyrighted by Sun Microsystems(C),
    Inc.

-   Software copyrighted by Gisle Aas. All rights
    reserved, (C) 1995-2003.

-   Software copyrighted by Michael A. Chase, (C)
    1999-2000.

-   Software copyrighted by Neil Winton, (C)
    1995-1996.

-   Software copyrighted by RSA Data Security, Inc.,
    (C) 1990-1992.

-   Software copyrighted by Sean M. Burke, (C) 1999,
    2000.

-   Software copyrighted by Martijn Koster, (C)
    1995.

-   Software copyrighted by Brad Appleton, (C)
    1996-1999.

-   Software copyrighted by Michael G. Schwern, (C)
    2001.

-   Software copyrighted by Graham Barr, (C) 1998.

-   Software copyrighted by Larry Wall and Clark
    Cooper, (C) 1998-2000.

-   Software copyrighted by Frodo Looijaard, (C)
    1997.


Deriv 2.3.1

DBN 146-EN


