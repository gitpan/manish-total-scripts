#!/bin/sh
cd /mcafee
rm dat_version.txt
ftp ftp.nai.com <<EOF
bin
hash
prompt
cd pub/antivirus/datfiles/4.x
mget readme.txt
bye
EOF
cur_dat_version=`cat oldreadme.txt | grep " DAT Version" | awk ' { print $4 }'`
new_dat_version=`cat readme.txt | grep " DAT Version" | awk ' { print $4 }'`
echo $cur_dat_version
echo $new_dat_version
if [ $cur_dat_version = $new_dat_version ]; then
   echo " No new DAT Version has come " > /mcafee/dat_version.txt
else
   echo " New  DAT Version $new_dat_version  has come. " > /mcafee/dat_version.txt
cd /mcafee/dat
rm -f *.*
ftp ftp.nai.com <<EOF
bin
hash
prompt
cd pub/antivirus/datfiles/4.x
lcd /mcafee/dat
mget *.tar
bye
EOF
cd /mcafee/dat
tar -xvf *.tar
files=`ls -asl *.dat | wc -l`
echo $files
if [ $files -eq 4 ]; then 
cp -f *.dat /usr/local/uvscan/
echo " New DAT have been successfully installed. Please check once more as confirmation on 221.171.85.16. If it is installed succesfully then you can copy the basic 4 files to other system from /usr/local/uvscan directory. " >> /mcafee/dat_version.txt
cp -f /mcafee/readme.txt /mcafee/oldreadme.txt
mail -s " New DAT Version $new_dat_version  has come " isgcs@hughes-ecomm.com < /mcafee/dat_version.txt
else
echo " New DAT is not downloaded successfully. Please download it and install it on 221.171.85.16 and other system. " >> /mcafee/dat_version.txt
mail -s " New DAT Version $new_dat_version   has come " isgcs@hughes-ecomm.com < /mcafee/dat_version.txt
fi
fi
