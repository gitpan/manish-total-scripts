#/bin/sh
echo Upading the latest dat file
cd /home/isgopr/temp
echo connecting to ftp.nai.com to download latest datfiles
/usr/kerberos/bin/ftp -n ftp.nai.com << END
quote user anonymous
quote pass anonymous
bin
hash
prompt
cd /pub/datfiles/english/
mget dat-*.tar
END
if [ $? -eq 0 ]; then
echo Datfiles downloaded successfully........
fi
#echo extracting datfiles to /home/isgopr/datfiles
#cd /home/isgopr/temp
#ls /home/isgopr/temp  > /home/isgopr/temp.txt

#tar -xvf  `cat /home/isgopr/temp.txt` -C /home/isgopr/temp/
#if [ $? -eq 0 ]; then
#echo Datfiles extracted successfully........
#fi

#cd /home/isgopr/datfiles/
#cp -f /home/isgopr/temp/clean.dat ./
#if [ $? -eq 0 ]; then
#echo clean.dat copied successfully
#fi

#cp -f /home/isgopr/temp/scan.dat ./
#if [ $? -eq 0 ]; then
#echo names.dat copied successfully
#fi
#cp -f /home/isgopr/temp/internet.dat ./
#if [ $? -eq 0 ]; then
#echo internet.dat copied successfully
#fi
#cp -f /home/isgopr/temp/names.dat ./
#if [ $? -eq 0 ]; then
#echo scan.dat copied successfully
#fi

#rm -rf /home/isgopr/temp/*.*
#rm -rf /home/igsopr/temp.txt
#if [ $? -eq 0 ]; then
#echo Temprary files removed.....
#fi

echo Latest datfiles successfully extracted to /home/isgopr/datfiles


