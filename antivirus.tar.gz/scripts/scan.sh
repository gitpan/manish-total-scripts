which uvscan > /scripts/temp1.txt
if [ -f /scripts/temp1.txt ]; then
echo "Scanning  partitons"
uvscan --analyse -v -r --summary --ignore-links --virus-list /boot > /var/log/scan.log
#echo "Scanning /home partition"
#uvscan --analyse -v -r --summary /home >> /var/log/scan.log
#echo "Scanning / partitions "
#uvscan --analyse -v -r --summary / >> /var/log/scan.log

else

echo "uvscan not installed"
fi
