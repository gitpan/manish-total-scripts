test1=`cat readme.txt | grep "Dat Version" | awk ' { print $4 }'`
echo $test1

