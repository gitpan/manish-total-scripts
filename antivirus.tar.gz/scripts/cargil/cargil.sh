#!/bin/sh
cd /home
ls -asl | grep cipl- | awk '{ print $10 }' >/scripts/cargil/cargilpoplist
sh /scripts/cargil/cargilmailboxsize.sh `cat /scripts/cargil/cargilpoplist`
