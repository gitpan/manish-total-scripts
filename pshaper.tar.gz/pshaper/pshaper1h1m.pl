#!/usr/bin/perl

($IP, $PASSWD, $TYPE, $PATH, $ENDTIME, $DAYS, $AVG)=@ARGV;

use Net::Telnet ();
  $t = new Net::Telnet (Timeout => 180,
			Prompt => '/.*\$.*/i');

  $t->open($IP);
  $t->waitfor('/Password: ?$/i');
  $t->print($PASSWD);
  $t->waitfor('/PacketShaper> /');
$t->print("measure dump $TYPE $PATH by time $DAYS $AVG avg-bps");

($output) = $t->waitfor('/PacketShaper> /');
print $output;     	

$t->print("exit");


$t->close;
