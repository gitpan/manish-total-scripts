#!/bin/sh
cd /home/pshaper/

ENDTIME=200510140000


LOGDIR=/home/pshaper/reports

for I in `cat pshaper1d1hold.conf|grep -v ^#|grep -v ^EndTime`
do

IP=`echo $I |cut -d ":" -f 1`
PASSWD=`echo $I|cut -d ":" -f 2`
TYPE=`echo $I|cut -d ":" -f 3`
Path=`echo $I|cut -d ":" -f 4`
Mail_To=`echo $I|cut -d ":" -f 5`
DAYS=`echo $I|cut -d ":" -f 6`
AVG=`echo $I|cut -d ":" -f 7`
FNAME=`echo $I|cut -d ":" -f 8`

echo "Taking report for $TYPE $Path ....."

#if [ "$IP" = "202.134.196.37" ]; then

#echo "In INternet"
#LOGDIR=/home/pshaper/reports
#fi


#if [ "$IP" = "221.171.85.252" ]; then

#echo "In Enterprise"
#LOGDIR=/home/pshaper/reports1
#fi

echo "perl pshaper1dold.pl $IP $PASSWD $TYPE $Path $ENDTIME $DAYS $AVG >
$LOGDIR/$FNAME-$ENDTIME.txt"

perl pshaper1dold.pl $IP $PASSWD $TYPE $Path $ENDTIME $DAYS $AVG > $LOGDIR/$IP-$FNAME-$ENDTIME.txt
done
